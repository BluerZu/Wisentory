﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Wisentory
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            //Activar el botón1 al presionar la tecla <Enter>.
            this.AcceptButton = button1;
            //Comprobar la conexión con la base de datos.
            if (connection.Conected()){
                label5.Text = "¡Exitosa!";
                label5.ForeColor = Color.Green;
            }
            else
            {
                label5.Text = "¡Fallida!";
                label5.ForeColor = Color.Red;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Autentificación de los datos ingresados por el usuario.
            DBFunctions connection = new DBFunctions();
            if (connection.AuthenticateUser(textBox1.Text, textBox2.Text))
            {
                MessageBox.Show("Bienvenido " + textBox1.Text.ToUpper() + "\n Puedes acceder a este programa.", "Ingreso correcto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                MainMenu mainMenu = new MainMenu();
                mainMenu.Show();
            }
            else
            {
                MessageBox.Show("Error, revise las credenciales.", "Ingreso erróneo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //Limpiamos las cajas de texto.
            textBox2.Text = "";
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
