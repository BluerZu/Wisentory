﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;

namespace Wisentory
{
    public partial class BillDetail : Form
    {
        public int BillDetailId { get; set; }
        int selectedId;
        public BillDetail()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Refresh(string productid = "", string productname = "")
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchBillDetail(BillDetailId, productid, productname);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void BillDetail_Load(object sender, EventArgs e)
        {
            Refresh();
            lbl_id.Text = "#" + BillDetailId.ToString();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            Refresh(txt_id.Text, txt_name.Text);
        }

        private void Clean(){
            txt_id.Text = "";
            txt_name.Text = "";
            txt_amount.Text = "";
        }

        private void btn_clean_Click(object sender, EventArgs e)
        {
            Clean();
            btn_add.Enabled = false;
            btn_search.Enabled = true;
            txt_name.Enabled = true;
            txt_id.Enabled = true;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_add.Enabled = true;
            btn_search.Enabled = false;
            txt_name.Enabled = false;
            txt_id.Enabled = true;
            txt_name.Focus();
        }
        private void GetId(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtener el valor de la columna "Id" de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Verificar si el valor no es nulo y luego intentar convertirlo a int
                if (row.Cells["IdProducto"].Value != null && int.TryParse(row.Cells["IdProducto"].Value.ToString(), out int id))
                {
                    // Almacenar el valor de la columna "Id" en la variable selectedId
                    selectedId = id;

                    // Mostrar los detalles del cliente seleccionado en los campos de texto
                    txt_id.Text = row.Cells["IdProducto"].Value.ToString();
                    txt_id.Enabled = false;
                    txt_name.Text = row.Cells["NombreProducto"].Value.ToString();
                    txt_amount.Text = row.Cells["Cantidad"].Value.ToString();

                    btn_modify.Enabled = true;
                    btn_delete.Enabled = true;
                    btn_search.Enabled = false;
                }
            }
            else
            {
                selectedId = -1;
            }
        }
        private bool Validations()
        {
            ValidationFunctions valid = new ValidationFunctions();
            // Validamos el campo "IdProducto"
            if (!valid.IsNotNull(txt_id.Text) || (!valid.IsNumeric(txt_id.Text)))
            {
                return false;
            }
            // Validamos el campo "Amount"
            if (!valid.IsNotNull(txt_amount.Text) || (!valid.IsPositiveInteger(txt_amount.Text)))
            {
                return false;
            }
            return true;
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();

            if (Validations())
            {
                connection.InsertBillDetail(BillDetailId, int.Parse(txt_id.Text), txt_amount.Text);
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        private void btn_modify_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            if (Validations())
            {
                connection.UpdateBillDetail(BillDetailId, selectedId, txt_amount.Text);
                btn_modify.Enabled = false;
                btn_delete.Enabled = false;
                btn_search.Enabled = true;
                txt_id.Enabled = true;
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btn_add.Enabled = false;
            txt_id.Enabled = false;
            GetId(e); // Obtiene el Id del cliente seleccionado
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.DeleteBillDetail(BillDetailId, selectedId);
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_search.Enabled = true;
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
        }
    }
}
