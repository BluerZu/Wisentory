﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;

namespace Wisentory
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
            DataGridViewCellStyle column0Style = new DataGridViewCellStyle();
            column0Style.Font = new Font("Arial", 12, FontStyle.Bold);
            column0Style.BackColor = Color.LightGray;
            column0Style.ForeColor = Color.Black;
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.FillTables("GetPagedClients");
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedProducts");
            dataGridView2.DataSource = dt;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedOrders");
            dataGridView3.DataSource = dt;
            dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedSuppliersOrders");
            dataGridView4.DataSource = dt;
            dataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedBills");
            dataGridView5.DataSource = dt;
            dataGridView5.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void MainMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
