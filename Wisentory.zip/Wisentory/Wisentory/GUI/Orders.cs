﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;

namespace Wisentory.GUI
{
    public partial class Orders : Form
    {
        int selectedId;
        public Orders()
        {
            InitializeComponent();
        }
        private void Refresh(string id = "", string date = "", string orderid = "", string status = "")
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchOrders(id, date, orderid,status);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void Orders_Load(object sender, EventArgs e)
        {
            Refresh();
            comboBox1.Items.Add("");
            comboBox1.Items.Add("Pendiente");
            comboBox1.Items.Add("Entregado");
            comboBox1.Items.Add("Cancelado");
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }



        private void Orders_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show(); // Abre el formulario MainMenu cuando se cierra el formulario Clients
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            Refresh(txt_id.Text, txt_date.Text, txt_supplierid.Text, comboBox1.Text);
        }
        private void Clean()
        {
            txt_id.Text = "";
            txt_date.Text = "";
            txt_supplierid.Text = "";
            comboBox1.Text = "";
        }

        private void btn_clean_Click(object sender, EventArgs e)
        {
            Clean();
            btn_add.Enabled = false;
            btn_search.Enabled = true;
            btn_details.Enabled = false;
            txt_id.Enabled = true;            
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_add.Enabled = true;
            btn_search.Enabled = false;
            txt_id.Enabled = false;
            btn_details.Enabled = false;
            txt_date.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txt_supplierid.Focus();
        }

        private void GetId(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtener el valor de la columna "Id" de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Verificar si el valor no es nulo y luego intentar convertirlo a int
                if (row.Cells["Id"].Value != null && int.TryParse(row.Cells["Id"].Value.ToString(), out int id))
                {
                    // Almacenar el valor de la columna "Id" en la variable selectedId
                    selectedId = id;

                    // Mostrar los detalles del cliente seleccionado en los campos de texto
                    txt_id.Text = row.Cells["Id"].Value.ToString();
                    txt_id.Enabled = false;
                    txt_date.Text = row.Cells["Fecha"].Value.ToString();
                    txt_supplierid.Text = row.Cells["IdProveedor"].Value.ToString();
                    comboBox1.Text = row.Cells["Estado"].Value.ToString();

                    btn_modify.Enabled = true;
                    btn_delete.Enabled = true;
                    btn_details.Enabled = true;
                    btn_search.Enabled = false;
                }
            }
            else
            {
                selectedId = -1;
            }
        }

        private bool Validations()
        {
            ValidationFunctions valid = new ValidationFunctions();

            // Validamos el campo "IdCliente"
            if (!valid.IsNotNull(txt_supplierid.Text) || !valid.IsNumeric(txt_supplierid.Text))
            {
                return false;
            }

            // Validamos el campo "Date"
            if (!valid.IsNotNull(txt_date.Text) || (!valid.IsDate(txt_date.Text)))
            {
                return false;
            }
            if (!valid.IsNotNull(comboBox1.Text))
            {
                return false;
            }
            return true;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();

            if (Validations())
            {
                connection.InsertOrder(txt_supplierid.Text, txt_date.Text, comboBox1.Text);
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }
        private void btn_modify_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            if (Validations())
            {
                connection.UpdateOrder(selectedId, txt_supplierid.Text, txt_date.Text, comboBox1.Text);
                btn_modify.Enabled = false;
                btn_delete.Enabled = false;
                btn_search.Enabled = true;
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btn_add.Enabled = false;
            GetId(e); // Obtiene el Id del cliente seleccionado
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.DeleteOrder(selectedId);
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_search.Enabled = true;
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
        }


        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_details_Click(object sender, EventArgs e)
        {
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.OrderDetailId = selectedId;
            orderDetail.ShowDialog();
            Refresh();
        }

    }    
}
