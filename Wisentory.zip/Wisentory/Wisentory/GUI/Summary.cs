﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;
using Wisentory.GUI;

namespace Wisentory
{
    public partial class Summary : Form
    {
        bool back = true;
        public Summary()
        {
            InitializeComponent();
        }

        private void Summary_Load(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.FillTables("GetPagedClients");
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedProducts");
            dataGridView2.DataSource = dt;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedOrders");
            dataGridView3.DataSource = dt;
            dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedSuppliersOrders");
            dataGridView4.DataSource = dt;
            dataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dt = connection.FillTables("GetPagedBills");
            dataGridView5.DataSource = dt;
            dataGridView5.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void Summary_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (back) 
            {
                MainMenu mainMenu = new MainMenu();
                mainMenu.Show();
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            back = false;
            this.Close();
            Orders order = new Orders();
            order.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            back = false;
            this.Close();
            Products products = new Products();
            products.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            back = false;
            this.Close();
            Bills bills = new Bills();
            bills.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            back = false;
            this.Close();
            Clients clients = new Clients();
            clients.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            back = false;
            this.Close();
            Suppliers suppliers = new Suppliers();
            suppliers.Show();
        }
    }
}
