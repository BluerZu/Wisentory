﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Wisentory
{
    public partial class BillDetail : Form
    {
        public int BillDetailId { get; set; }
        int selectedId;
        public BillDetail()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Refresh(string productid = "", string productname = "")
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchBillDetail(BillDetailId, productid, productname);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void BillDetail_Load(object sender, EventArgs e)
        {
            Refresh();
            DBFunctions connection = new DBFunctions();
            comboBox1.DataSource = connection.ProductsList("ProductInfo");
            comboBox1.DisplayMember = "Nombre";
            comboBox1.ValueMember = "Id";
            comboBox2.DataSource = connection.ProductsList("ProductInfo");
            comboBox2.DisplayMember = "Id";
            comboBox2.ValueMember = "Id";
            comboBox1.Text = "";
            comboBox2.Text = "";
            lbl_id.Text = "#" + BillDetailId.ToString();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            Refresh(comboBox2.Text, comboBox1.Text);
        }

        private void Clean(){
            txt_amount.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void btn_clean_Click(object sender, EventArgs e)
        {
            Clean();
            btn_add.Enabled = false;
            btn_search.Enabled = true;
        }
        
        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_add.Enabled = true;
            btn_search.Enabled = false;
            txt_amount.Focus();
        }
        private void GetId(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtener el valor de la columna "Id" de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Verificar si el valor no es nulo y luego intentar convertirlo a int
                if (row.Cells["IdProducto"].Value != null && int.TryParse(row.Cells["IdProducto"].Value.ToString(), out int id))
                {
                    // Almacenar el valor de la columna "Id" en la variable selectedId
                    selectedId = id;

                    // Mostrar los detalles del cliente seleccionado en los campos de texto
                    comboBox2.Text = row.Cells["IdProducto"].Value.ToString();
                    comboBox1.Text = row.Cells["NombreProducto"].Value.ToString();
                    txt_amount.Text = row.Cells["Cantidad"].Value.ToString();

                    btn_modify.Enabled = true;
                    btn_delete.Enabled = true;
                    btn_search.Enabled = false;
                }
            }
            else
            {
                selectedId = -1;
            }
        }       
        private bool Validations()
        {
            ValidationFunctions valid = new ValidationFunctions();
            // Validamos el campo "IdProducto"
            if (!valid.IsNotNull(comboBox2.Text) || (!valid.IsNumeric(comboBox2.Text)))
            {
                return false;
            }
            if (!valid.IsNotNull(comboBox1.Text))
            {
                return false;
            }
            // Validamos el campo "Amount"
            if (!valid.IsNotNull(txt_amount.Text) || (!valid.IsPositiveInteger(txt_amount.Text)))
            {
                return false;
            }
            return true;
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();

            if (Validations())
            {
                connection.InsertBillDetail(BillDetailId, int.Parse(comboBox2.Text), txt_amount.Text);
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        private void btn_modify_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            if (Validations())
            {
                connection.UpdateBillDetail(BillDetailId, selectedId, txt_amount.Text);
                btn_modify.Enabled = false;
                btn_delete.Enabled = false;
                btn_search.Enabled = true;
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btn_add.Enabled = false;
            GetId(e); // Obtiene el Id del cliente seleccionado
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.DeleteBillDetail(BillDetailId, selectedId);
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_search.Enabled = true;
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Text = comboBox1.SelectedValue.ToString();
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener el elemento seleccionado en comboBox2
            if (comboBox2.SelectedItem is DataRowView filaSeleccionada)
            {
                // Obtener el nombre asociado al valor seleccionado
                string nombreSeleccionado = filaSeleccionada["Nombre"].ToString();

                // Establecer el nombre en comboBox1
                comboBox1.Text = nombreSeleccionado;
            }
        }

        private void comboBox2_Validating(object sender, CancelEventArgs e)
        {
            string textoIngresado = comboBox2.Text;

            // Verificar si el texto ingresado está dentro de las opciones del ComboBox
            if (!comboBox2.Items.Cast<DataRowView>().Any(item => item[comboBox2.DisplayMember].ToString().Equals(textoIngresado)))
            {
                // Mostrar un mensaje de error y restaurar la selección anterior.
                e.Cancel = true;
                MessageBox.Show("El valor ingresado no está dentro de las opciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Obtener el elemento seleccionado en comboBox2
                if (comboBox2.SelectedItem is DataRowView filaSeleccionada)
                {
                    // Obtener el nombre asociado al valor seleccionado
                    string nombreSeleccionado = filaSeleccionada["Nombre"].ToString();

                    // Establecer el nombre en comboBox1
                    comboBox1.Text = nombreSeleccionado;
                }
            }
        }        
        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            string textoIngresado = comboBox1.Text;

            // Verificar si el texto ingresado está dentro de las opciones del ComboBox
            if (!comboBox1.Items.Cast<DataRowView>().Any(item => item[comboBox1.DisplayMember].ToString().Equals(textoIngresado)))
            {
                // Mostrar un mensaje de error y restaurar la selección anterior.
                e.Cancel = true;
                MessageBox.Show("El valor ingresado no está dentro de las opciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                comboBox2.Text = comboBox1.SelectedValue.ToString();
            }
        }
    }
}
