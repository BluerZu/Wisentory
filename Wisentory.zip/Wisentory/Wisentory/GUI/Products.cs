﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;
using static System.Net.Mime.MediaTypeNames;

namespace Wisentory.GUI
{
    public partial class Products : Form
    {
        int selectedId; // Variable para almacenar el Id del cliente seleccionado
        DataTable dt = new DataTable();
        public Products()
        {
            InitializeComponent();
        }
        private void startCombobox()
        {
            DBFunctions connection = new DBFunctions();
            comboBox1.Items.Add("");
            comboBox1.Items.Add("Sí");
            comboBox1.Items.Add("No");
            dt = connection.ProductsList("SupplierInfo");
            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "Nombre";
            comboBox2.ValueMember = "Id";
            comboBox2.SelectedValue = 0;
            comboBox2.Text = "";
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }
        private void Products_Load(object sender, EventArgs e)
        {
            startCombobox();
            Refresh();
        }
        private void Refresh(string id = "", string name = "", string description = "", string vat = "", string sell = "", string buy = "", string stock = "", string supplierid = "")
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchProducts(id, name, description, vat, sell, buy, stock, supplierid);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Products_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show(); // Abre el formulario MainMenu cuando se cierra el formulario Clients
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "")
            {
                Refresh(txt_id.Text, txt_name.Text, txt_description.Text, comboBox1.Text, txt_sell.Text, txt_buy.Text, txt_stock.Text);
            }else
            {
                Refresh(txt_id.Text, txt_name.Text, txt_description.Text, comboBox1.Text, txt_sell.Text, txt_buy.Text, txt_stock.Text, comboBox2.SelectedValue.ToString());
            }            
        }
        private void Clean()
        {
            txt_id.Text = "";
            txt_name.Text = "";
            txt_buy.Text = "";
            txt_description.Text = "";
            txt_sell.Text = "";
            txt_stock.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_add.Enabled = true;
            btn_search.Enabled = false;
            txt_id.Enabled = false;
            txt_name.Focus(); // Establece el enfoque en el campo "Nombre" para ingresar datos del nuevo cliente
        }
        private bool Validations()
        {
            ValidationFunctions valid = new ValidationFunctions();

            // Validamos el campo "Nombre"
            if (!valid.IsNotNull(txt_name.Text))
            {
                return false;
            }

            // Validamos el campo "PrecioCompra"
            if (!valid.IsNotNull(txt_buy.Text) || !valid.IsPositiveDecimal(txt_buy.Text))
            {
                return false;
            }

            // Validamos el campo "Stock"
            if (!valid.IsNotNull(txt_stock.Text) || !valid.IsPositiveInteger(txt_stock.Text))
            {
                return false;
            }

            // Validamos el campo "IVA"
            if (!valid.IsNotNull(comboBox1.Text))
            {
                return false;
            }
            // Validamos el campo "Proveedor"
            if (!valid.IsNotNull(comboBox2.Text))
            {
                return false;
            }

            // Validamos el campo "PrecioVenta"
            if (!valid.IsNotNull(txt_sell.Text) || !valid.IsPositiveDecimal(txt_sell.Text))
            {
                return false;
            }
            return true;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();

            if (Validations())
            {
                ValidationFunctions valid = new ValidationFunctions();
                connection.InsertProduct(txt_name.Text,txt_description.Text,comboBox1.Text, valid.putComa(txt_buy.Text), valid.putComa(txt_sell.Text),txt_stock.Text,comboBox2.SelectedValue.ToString());
                Clean();
                Refresh(); // Refresca los datos en el DataGridView

            }
        }
        private void GetId(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtener el valor de la columna "Id" de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Verificar si el valor no es nulo y luego intentar convertirlo a int
                if (row.Cells["Id"].Value != null && int.TryParse(row.Cells["Id"].Value.ToString(), out int id))
                {
                    // Almacenar el valor de la columna "Id" en la variable selectedId
                    selectedId = id;

                    // Mostrar los detalles del cliente seleccionado en los campos de texto
                    string temp = (row.Cells["IdProveedor"].Value.ToString());
                    comboBox2.SelectedValue = int.Parse(temp);
                    comboBox1.Text = row.Cells["Impuesto"].Value.ToString();
                    txt_stock.Text = row.Cells["Stock"].Value.ToString();
                    txt_name.Text = row.Cells["Nombre"].Value.ToString();
                    txt_id.Text = row.Cells["Id"].Value.ToString();
                    txt_description.Text = row.Cells["Descripción"].Value.ToString();
                    txt_buy.Text = row.Cells["PrecioCompra"].Value.ToString();
                    txt_sell.Text = row.Cells["PrecioVenta"].Value.ToString();

                    btn_modify.Enabled = true;
                    btn_delete.Enabled = true;
                    btn_search.Enabled = false;
                }
            }
            else
            {
                selectedId = -1;
            }
        }

        private void comboBox2_Validating(object sender, CancelEventArgs e)
        {
            string textoIngresado = comboBox2.Text;

            // Verificar si el texto ingresado está dentro de las opciones del ComboBox
            if (!comboBox2.Items.Cast<DataRowView>().Any(item => item[comboBox2.DisplayMember].ToString().Equals(textoIngresado)))
            {
                // Mostrar un mensaje de error y restaurar la selección anterior.
                e.Cancel = true;
                MessageBox.Show("El valor ingresado no está dentro de las opciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Obtener el elemento seleccionado en comboBox2
                if (comboBox2.SelectedItem is DataRowView filaSeleccionada)
                {
                    // Obtener el nombre asociado al valor seleccionado
                    string nombreSeleccionado = filaSeleccionada["Nombre"].ToString();

                    // Establecer el nombre en comboBox1
                    comboBox1.Text = nombreSeleccionado;
                }
            }
        }

        private void btn_clean_Click(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_name.Text = "";
            txt_buy.Text = "";
            txt_description.Text = "";
            txt_sell.Text = "";
            startCombobox();
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void btn_modify_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            if (Validations())
            {                
                ValidationFunctions valid = new ValidationFunctions();
                connection.UpdateProduct(selectedId, txt_name.Text, txt_description.Text, comboBox1.Text, valid.putComa(txt_buy.Text), valid.putComa(txt_sell.Text), txt_stock.Text, comboBox2.SelectedValue.ToString());
                btn_modify.Enabled = false;
                btn_delete.Enabled = false;
                btn_search.Enabled = true;
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btn_add.Enabled = false;
            GetId(e); // Obtiene el Id del cliente seleccionado
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.DeleteProduct(selectedId);
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_search.Enabled = true;
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
        }
    }
}
