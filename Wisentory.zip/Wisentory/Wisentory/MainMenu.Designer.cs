﻿namespace Wisentory
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.label1 = new System.Windows.Forms.Label();
            this.btn_summary = new System.Windows.Forms.Button();
            this.btn_orders = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_bills = new System.Windows.Forms.Button();
            this.btn_clients = new System.Windows.Forms.Button();
            this.btn_products = new System.Windows.Forms.Button();
            this.btn_suppliers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(83, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "MENÚ PRINCIPAL";
            // 
            // btn_summary
            // 
            this.btn_summary.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_summary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_summary.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_summary.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_summary.FlatAppearance.BorderSize = 0;
            this.btn_summary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_summary.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_summary.ForeColor = System.Drawing.Color.White;
            this.btn_summary.Location = new System.Drawing.Point(12, 50);
            this.btn_summary.Name = "btn_summary";
            this.btn_summary.Size = new System.Drawing.Size(197, 57);
            this.btn_summary.TabIndex = 20;
            this.btn_summary.Text = "Ver Resumen";
            this.btn_summary.UseVisualStyleBackColor = false;
            this.btn_summary.Click += new System.EventHandler(this.btn_summary_Click);
            // 
            // btn_orders
            // 
            this.btn_orders.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_orders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_orders.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_orders.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_orders.FlatAppearance.BorderSize = 0;
            this.btn_orders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_orders.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_orders.ForeColor = System.Drawing.Color.White;
            this.btn_orders.Location = new System.Drawing.Point(12, 113);
            this.btn_orders.Name = "btn_orders";
            this.btn_orders.Size = new System.Drawing.Size(197, 57);
            this.btn_orders.TabIndex = 21;
            this.btn_orders.Text = " Ver Pedidos";
            this.btn_orders.UseVisualStyleBackColor = false;
            // 
            // btn_exit
            // 
            this.btn_exit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_exit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.Location = new System.Drawing.Point(113, 239);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(197, 57);
            this.btn_exit.TabIndex = 22;
            this.btn_exit.Text = "Salir";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_bills
            // 
            this.btn_bills.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_bills.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_bills.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_bills.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_bills.FlatAppearance.BorderSize = 0;
            this.btn_bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bills.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bills.ForeColor = System.Drawing.Color.White;
            this.btn_bills.Location = new System.Drawing.Point(216, 50);
            this.btn_bills.Name = "btn_bills";
            this.btn_bills.Size = new System.Drawing.Size(197, 57);
            this.btn_bills.TabIndex = 23;
            this.btn_bills.Text = "Ver Facturas";
            this.btn_bills.UseVisualStyleBackColor = false;
            this.btn_bills.Click += new System.EventHandler(this.btn_bills_Click);
            // 
            // btn_clients
            // 
            this.btn_clients.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_clients.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_clients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_clients.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_clients.FlatAppearance.BorderSize = 0;
            this.btn_clients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clients.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clients.ForeColor = System.Drawing.Color.White;
            this.btn_clients.Location = new System.Drawing.Point(12, 176);
            this.btn_clients.Name = "btn_clients";
            this.btn_clients.Size = new System.Drawing.Size(197, 57);
            this.btn_clients.TabIndex = 25;
            this.btn_clients.Text = "Ver Clientes";
            this.btn_clients.UseVisualStyleBackColor = false;
            this.btn_clients.Click += new System.EventHandler(this.btn_clients_Click);
            // 
            // btn_products
            // 
            this.btn_products.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_products.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_products.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_products.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_products.FlatAppearance.BorderSize = 0;
            this.btn_products.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_products.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_products.ForeColor = System.Drawing.Color.White;
            this.btn_products.Location = new System.Drawing.Point(215, 113);
            this.btn_products.Name = "btn_products";
            this.btn_products.Size = new System.Drawing.Size(197, 57);
            this.btn_products.TabIndex = 24;
            this.btn_products.Text = " Ver Productos";
            this.btn_products.UseVisualStyleBackColor = false;
            // 
            // btn_suppliers
            // 
            this.btn_suppliers.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_suppliers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(76)))), ((int)(((byte)(150)))));
            this.btn_suppliers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_suppliers.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.btn_suppliers.FlatAppearance.BorderSize = 0;
            this.btn_suppliers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_suppliers.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_suppliers.ForeColor = System.Drawing.Color.White;
            this.btn_suppliers.Location = new System.Drawing.Point(215, 176);
            this.btn_suppliers.Name = "btn_suppliers";
            this.btn_suppliers.Size = new System.Drawing.Size(197, 57);
            this.btn_suppliers.TabIndex = 26;
            this.btn_suppliers.Text = "Ver Proveedores";
            this.btn_suppliers.UseVisualStyleBackColor = false;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(196)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(425, 299);
            this.Controls.Add(this.btn_suppliers);
            this.Controls.Add(this.btn_clients);
            this.Controls.Add(this.btn_products);
            this.Controls.Add(this.btn_bills);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_orders);
            this.Controls.Add(this.btn_summary);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainMenu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainMenu_FormClosed);
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_summary;
        private System.Windows.Forms.Button btn_orders;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_bills;
        private System.Windows.Forms.Button btn_clients;
        private System.Windows.Forms.Button btn_products;
        private System.Windows.Forms.Button btn_suppliers;
    }
}