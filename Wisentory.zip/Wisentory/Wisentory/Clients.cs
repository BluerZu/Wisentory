﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Wisentory.Classes;
// Otras librerías utilizadas

namespace Wisentory
{
    public partial class Clients : Form
    {
        int selectedId; // Variable para almacenar el Id del cliente seleccionado

        public Clients()
        {
            InitializeComponent();
        }

        // Evento Load del formulario Clients
        private void Clients_Load(object sender, EventArgs e)
        {
            Refresh(); // Carga inicial de datos en el DataGridView
        }

        // Botón "Salir" - Cierra el formulario
        private void btn_exit_Click(object sender, EventArgs e)
        {            
            Application.Exit();
        }

        // Botón "Atrás" - Cierra la aplicación
        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Evento FormClosed del formulario Clients
        private void Clients_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show(); // Abre el formulario MainMenu cuando se cierra el formulario Clients
        }

        // Botón "Buscar" - Refresca los datos en el DataGridView según los criterios de búsqueda
        private void btn_search_Click(object sender, EventArgs e)
        {
            Refresh(txt_id.Text, txt_name.Text, txt_lastname.Text, txt_number.Text, txt_email.Text);
        }

        // Limpia los campos de texto
        private void Clean()
        {
            txt_id.Text = "";
            txt_name.Text = "";
            txt_lastname.Text = "";
            txt_number.Text = "";
            txt_email.Text = "";
        }

        // Botón "Nuevo" - Prepara el formulario para agregar un nuevo cliente
        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_add.Enabled = true;
            btn_search.Enabled = false;
            txt_id.Enabled = false;
            txt_name.Focus(); // Establece el enfoque en el campo "Nombre" para ingresar datos del nuevo cliente
        }

        // Botón "Agregar" - Agrega un nuevo cliente a la base de datos
        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();

            if (Validations())
            {
                connection.InsertClient(txt_name.Text, txt_lastname.Text, txt_number.Text, txt_email.Text);
                Clean();
                Refresh(); // Refresca los datos en el DataGridView
                
            }
        }

        // Realiza las validaciones de los campos del formulario
        private bool Validations()
        {
            ValidationFunctions valid = new ValidationFunctions();

            // Validamos el campo "Nombre"
            if (!valid.IsNotNull(txt_name.Text) || !valid.NoNumbers(txt_name.Text))
            {
                return false;
            }

            // Validamos el campo "Apellido"
            if (!valid.IsNotNull(txt_lastname.Text) || !valid.NoNumbers(txt_lastname.Text))
            {
                return false;
            }

            // Validamos el campo "Número"
            if (!string.IsNullOrEmpty(txt_number.Text) && txt_number.Text != "N/A")
            {
                if (!valid.IsNumber(txt_number.Text))
                {
                    return false;
                }
            }

            // Validamos el campo "Email"
            if (!string.IsNullOrEmpty(txt_email.Text) && txt_email.Text != "N/A")
            {
                if (!valid.IsMail(txt_email.Text))
                {
                    return false;
                }
            }
            return true;
        }

        // Refresca los datos en el DataGridView según los criterios de búsqueda
        private void Refresh(string id = "", string name = "", string lastname = "", string number = "", string email = "")
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchClients(id, name, lastname, number, email);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        // Evento CellClick del DataGridView - Se activa cuando el usuario hace clic en una celda
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btn_add.Enabled = false;
            GetId(e); // Obtiene el Id del cliente seleccionado
        }

        // Obtiene el Id del cliente seleccionado en el DataGridView
        private void GetId(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtener el valor de la columna "Id" de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Verificar si el valor no es nulo y luego intentar convertirlo a int
                if (row.Cells["Id"].Value != null && int.TryParse(row.Cells["Id"].Value.ToString(), out int id))
                {
                    // Almacenar el valor de la columna "Id" en la variable selectedId
                    selectedId = id;

                    // Mostrar los detalles del cliente seleccionado en los campos de texto
                    txt_id.Text = row.Cells["Id"].Value.ToString();
                    txt_id.Enabled = false;
                    txt_name.Text = row.Cells["Nombre"].Value.ToString();
                    txt_lastname.Text = row.Cells["Apellido"].Value.ToString();
                    txt_number.Text = row.Cells["Número"].Value.ToString();
                    txt_email.Text = row.Cells["Email"].Value.ToString();

                    btn_modify.Enabled = true;
                    btn_delete.Enabled = true;
                    btn_search.Enabled = false;
                }
            } else
            {
                selectedId = -1;
            }
        }

        // Botón "Modificar" - Modifica los datos del cliente seleccionado en la base de datos
        private void btn_modify_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            if (Validations())
            {
                connection.UpdateClient(selectedId, txt_name.Text, txt_lastname.Text, txt_number.Text, txt_email.Text);
                btn_modify.Enabled = false;
                btn_delete.Enabled = false;
                btn_search.Enabled = true;
                Clean();
                Refresh(); // Refresca los datos en el DataGridView                
            }
        }

        // Botón "Eliminar" - Elimina el cliente seleccionado de la base de datos
        private void btn_delete_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.DeleteClient(selectedId);
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            btn_search.Enabled = true;
            Clean();
            Refresh(); // Refresca los datos en el DataGridView
            
        }

        private void btn_clean_Click(object sender, EventArgs e)
        {
            Clean();
            Refresh();
            btn_add.Enabled = false;
            btn_search.Enabled = true;
            btn_modify.Enabled = false;
            btn_delete.Enabled = false;
            txt_id.Enabled = true;
        }
    }
}
