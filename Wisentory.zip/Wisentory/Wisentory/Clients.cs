﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;

namespace Wisentory
{
    public partial class Clients : Form
    {
        public Clients()
        {
            InitializeComponent();
        }

        private void Clients_Load(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchClients();
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Clients_FormClosed(object sender, FormClosedEventArgs e)
        {            
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            DataTable dt = connection.SearchClients(txt_name.Text,txt_lastname.Text,txt_number.Text,txt_email.Text);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }
        private void Clean()
        {
            txt_name.Text = "";
            txt_lastname.Text = "";
            txt_number.Text = "";
            txt_email.Text = "";
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            Clean();
            btn_add.Enabled = true;
            txt_name.Focus();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            DBFunctions connection = new DBFunctions();
            connection.InsertClient(txt_name.Text, txt_lastname.Text, txt_number.Text, txt_email.Text);
            Clean();
        }
    }
}
