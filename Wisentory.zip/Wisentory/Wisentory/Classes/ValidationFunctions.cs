﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Wisentory.Classes
{
    internal class ValidationFunctions
    {
        public Boolean IsNumber(string text)
        {
            // Intentar convertir el texto a un número entero
            int number;
            bool isNumber = int.TryParse(text, out number);

            // Devolver "true" si es un número, "false" si es una cadena
            if (!isNumber || text.Length < 10)
            {
                MessageBox.Show($"Error, la cadena '{text}' no debe contener letras y debe tener 10 dígitos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            // Devolver true si es un número
            return true;
        }
        public bool NoNumbers(string text)
        {
            // Recorrer cada carácter de la cadena
            foreach (char c in text)
            {
                // Verificar si el carácter es un dígito numérico
                if (char.IsDigit(c))
                {
                    MessageBox.Show($"Error, la cadena '{text}' no debe contener números", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; // Si se encuentra un dígito numérico, la cadena tiene números
                }
            }

            // Si no se encontraron dígitos numéricos, la cadena no tiene números
            return true;
        }

        public bool IsNotNull (string text)
        {
            // Verificar si la cadena es nula o vacía
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Error, por favor revise que no hayan casillas de texto vacías.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false; // Si la cadena es nula o vacía, se considera que tiene números
            }
            return true;
        }

        public bool IsMail (string text)
        {
            // Patrón de la expresión regular para validar el email.
            // Esta expresión cubre muchos casos comunes de direcciones de correo electrónico válidas,
            // pero no es 100% exhaustiva y no garantiza que el correo electrónico exista realmente.
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            bool isMail = Regex.IsMatch(text, pattern);
            // Utilizamos Regex.IsMatch para verificar si el email coincide con el patrón de la expresión regular.
            if (!isMail)
            {
                MessageBox.Show("Error, por favor revise que el email sea válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return isMail; // Si la cadena no es un email válido
            }
            return isMail;
        }

    }


}
