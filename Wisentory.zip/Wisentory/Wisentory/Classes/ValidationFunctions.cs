﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wisentory.Classes
{
    internal class ValidationFunctions
    {
        public Boolean Number(string text)
        {
            // Intentar convertir el texto a un número entero
            int number;
            bool isNumber = int.TryParse(text, out number);

            // Devolver "true" si es un número, "false" si es una cadena
            return isNumber;
        }
        public bool NoNumbers(string text)
        {
            // Verificar si la cadena es nula o vacía
            if (string.IsNullOrEmpty(text))
            {
                return false; // Si la cadena es nula o vacía, se considera que tiene números
            }

            // Recorrer cada carácter de la cadena
            foreach (char c in text)
            {
                // Verificar si el carácter es un dígito numérico
                if (char.IsDigit(c))
                {
                    return false; // Si se encuentra un dígito numérico, la cadena tiene números
                }
            }

            // Si no se encontraron dígitos numéricos, la cadena no tiene números
            return true;
        }

    }


}
