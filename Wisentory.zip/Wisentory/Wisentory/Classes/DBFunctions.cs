﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Net.Mime.MediaTypeNames;
using System.Globalization;
using System.Deployment.Internal;
using System.Drawing.Printing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Wisentory.Classes
{
    internal class DBFunctions
    {
        private string strconnection = ConfigurationManager.ConnectionStrings["WisentoryDB"].ConnectionString;
        //Clase que realiza la conexión con la base de datos.
        private SqlConnection GetConnection()
        {
            return new SqlConnection(strconnection);
        }

        public bool Conected()
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }

        //Clase que nos permite autentificar si el usuario es válido.
        public bool AuthenticateUser(string username, string password)
        {
            using (SqlConnection connection = GetConnection())
            {
                string query = "SELECT COUNT(*) FROM Users WHERE Name = @Name AND BINARY_CHECKSUM(Password) = BINARY_CHECKSUM(@Password)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    //Comandos para la sanitización de los datos.
                    command.Parameters.AddWithValue("@Name", username);
                    command.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        int count = (int)command.ExecuteScalar();
                        connection.Close();
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                        return false;
                    }

                }
            }
        }

        public DataTable ProductsList(string view)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT * FROM " + view, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.SelectCommand = command;
                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public DataTable FillClients(int pageNumber = 1, int pageSize = 5)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("GetPagedClients"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@PageNumber", pageNumber);
                        command.Parameters.AddWithValue("@PageSize", pageSize);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public DataTable FillTables(string procedure, int pageNumber = 1, int pageSize = 5)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(procedure))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@PageNumber", pageNumber);
                        command.Parameters.AddWithValue("@PageSize", pageSize);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }  

        public DataTable SearchClients(string id = "", string name = "", string lastname = "", string number = "", string email = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchClients"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Lastname", lastname);
                        command.Parameters.AddWithValue("@Number", number);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public void InsertClient(string name, string lastName, string phoneNumber = "", string email = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertClient", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        name = char.ToUpper(name[0]) + name.ToLower().Substring(1);
                        lastName = char.ToUpper(lastName[0]) + lastName.ToLower().Substring(1);

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        if (phoneNumber != "") {
                            command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        }
                        if (email != "")
                        {
                            command.Parameters.AddWithValue("@Email", email.ToLower());
                        }
                        

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Cliente agregado correctamente.", "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateClient(int id, string name, string lastName, string phoneNumber = "", string email = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateClient", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        name = char.ToUpper(name[0]) + name.ToLower().Substring(1);
                        lastName = char.ToUpper(lastName[0]) + lastName.ToLower().Substring(1);

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        if (phoneNumber != "" && phoneNumber != "N/A")
                        {
                            command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        }
                        if (email != "" && email != "N/A")
                        {
                            command.Parameters.AddWithValue("@Email", email.ToLower());
                        }

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Cliente modificado correctamente.", "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteClient(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteClient", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Cliente borrado correctamente.", "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable SearchBills(string id = "", string date = "", string clientid = "", string total = "", string condition = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchBills"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@Id", id);
                        if (date != "")
                        {
                            command.Parameters.AddWithValue("@Date", date);
                        }                        
                        command.Parameters.AddWithValue("@ClientId", clientid);
                        if (total != "")
                        {
                            command.Parameters.AddWithValue("@Total", double.Parse(total));
                        }
                        if (condition != "")
                        {
                            command.Parameters.AddWithValue("@Condition", condition);
                        }                        
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public void InsertBill(string clientid, string date)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertBill", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@IdCliente", int.Parse(clientid));
                        command.Parameters.AddWithValue("@Fecha", DateTime.Parse(date));

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Factura agregada correctamente.", "Facturas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar la factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateBill(int id, string clientid, string date)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateBill", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Clientid", int.Parse(clientid));
                        command.Parameters.AddWithValue("@Date", DateTime.Parse(date));
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Factura modificada correctamente.", "Factura", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar la factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteBill(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteBill", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Factura borrada correctamente.", "Facturas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable SearchBillDetail(int id, string productid = "", string productname = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchBillDetail"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@BillId", id);
                        if (productid != "")
                        {
                            command.Parameters.AddWithValue("@ProductId", productid);
                        }                        
                        if (productname != "")
                        {
                            command.Parameters.AddWithValue("@ProductName", productname);
                        }

                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }
        public void InsertBillDetail(int id, int productid, string amount)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertBillDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@BillId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);
                        command.Parameters.AddWithValue("@Amount", int.Parse(amount));

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Factura agregada correctamente.", "Detalle de Factura", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el detalle factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateBillDetail(int id, int productid, string amount)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateBillDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@BillId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);
                        command.Parameters.AddWithValue("@Amount", int.Parse(amount));
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Factura modificada correctamente.", "Detalle de Factura", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar el detalle factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteBillDetail(int id, int productid)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteBillDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@BillId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Factura borrado correctamente.", "Detalle de Factura", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el detalle del pedido: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable SearchSuppliers(string id="", string name = "", string email = "", string number = "", string address = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchSuppliers"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@Id", id);
                        if (name != "")
                        {
                            command.Parameters.AddWithValue("@Name", name);
                        }
                        if (email != "")
                        {
                            command.Parameters.AddWithValue("@Email", email);
                        }
                        if (number != "" || number != "N/A")
                        {
                            command.Parameters.AddWithValue("@PhoneNumber", number);
                        }
                        if (address != "")
                        {
                            command.Parameters.AddWithValue("@Address", address);
                        }

                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }
        public void InsertSupplier(string name, string email, string number, string address)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertSupplier", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Email", email);
                        if (number != "" || number != "N/A")
                        {
                            command.Parameters.AddWithValue("@PhoneNumber", number);
                        }
                        command.Parameters.AddWithValue("@Address", address);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Proveedor agregado correctamente.", "Proveedor", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el Proveedor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateSupplier(int id, string name, string email, string number, string address)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateSupplier", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Email", email);
                        if (number != "" || number != "N/A")
                        {
                            command.Parameters.AddWithValue("@PhoneNumber", number);
                        }
                        command.Parameters.AddWithValue("@Address", address);
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Proveedor modificado correctamente.", "Proveedor", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar el Proveedor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteSupplier(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteSupplier", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Proveedor borrado correctamente.", "Proveedor", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el Proveedor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public DataTable SearchOrders(string id = "", string supplierId = "", string date = "", string status = "") // Agregar el parámetro "status" en la función
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchOrders"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@OrderId", id);
                        if (date != "")
                        {
                            command.Parameters.AddWithValue("@Date", date);
                        }
                        if (supplierId != "")
                        {
                            command.Parameters.AddWithValue("@SupplierId", supplierId);
                        }
                        if (status != "")
                        {
                            command.Parameters.AddWithValue("Status", status);
                        }

                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar órdenes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dataTable;
        }

        public void InsertOrder(string supplierId, string date, string status)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertOrder", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Date", DateTime.Parse(date));
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierId));

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Orden agregada correctamente.", "Orden", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar la Orden: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateOrder(int orderId, string supplierId, string date, string status)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateOrder", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@OrderId", orderId);
                        command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierId));
                        command.Parameters.AddWithValue("@Date", DateTime.Parse(date));
                        command.Parameters.AddWithValue("@Status", status);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Orden modificada correctamente.", "Orden", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar la orden: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteOrder(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteOrder", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Orden borrada correctamente.", "Órdenes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar la Orden: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable SearchProducts(string id = "", string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "") // Agregar el parámetro "status" en la función
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchProducts"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Description", description);
                        if (vat == "Sí")
                        {
                            command.Parameters.AddWithValue("@VAT", "Y");
                        }
                        if (vat == "No")
                        {
                            command.Parameters.AddWithValue("@VAT", "N");
                        }
                        if (buyprice != "")
                        {
                            command.Parameters.AddWithValue("@BuyPrice", double.Parse(buyprice));
                        }
                        if (sellprice != "")
                        {
                            command.Parameters.AddWithValue("@SellPrice", double.Parse(sellprice));
                        }
                        if (stock != "")
                        {
                            command.Parameters.AddWithValue("@Stock", int.Parse(stock));
                        }
                        if (supplierid != "")
                        {
                            command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierid));
                        }                        
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar los productos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dataTable;
        }
        public void InsertProduct(string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Description", description);
                        if (vat == "Sí")
                        {
                            command.Parameters.AddWithValue("@VAT", "Y");
                        }
                        if (vat == "No")
                        {
                            command.Parameters.AddWithValue("@VAT", "N");
                        }
                        command.Parameters.AddWithValue("@BuyPrice", double.Parse(buyprice));
                        command.Parameters.AddWithValue("@SellPrice", double.Parse(sellprice));
                        command.Parameters.AddWithValue("@Stock", int.Parse(stock));
                        command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierid));

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Producto agregada correctamente.", "Producto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el Producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateProduct(int id, string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Description", description);
                        if (vat == "Sí")
                        {
                            command.Parameters.AddWithValue("@VAT", "Y");
                        }
                        if (vat == "No")
                        {
                            command.Parameters.AddWithValue("@VAT", "N");
                        }
                        command.Parameters.AddWithValue("@BuyPrice", double.Parse(buyprice));
                        command.Parameters.AddWithValue("@SellPrice", double.Parse(sellprice));
                        command.Parameters.AddWithValue("@Stock", int.Parse(stock));
                        command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierid));
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Producto modificado correctamente.", "Producto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar el producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteProduct(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteProduct", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Id", id);
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Producto borrado correctamente.", "Productos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el Producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable SearchOrderDetail(int id, string productid = "", string productname = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchOrderDetail"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@OrderId", id);
                        if (productid != "")
                        {
                            command.Parameters.AddWithValue("@ProductId", productid);
                        }
                        if (productname != "")
                        {
                            command.Parameters.AddWithValue("@ProductName", productname);
                        }

                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }
        public void InsertOrderDetail(int id, int productid, string amount)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertOrderDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@OrderId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);
                        command.Parameters.AddWithValue("@Amount", int.Parse(amount));

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Pedido agregada correctamente.", "Detalle de Pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el detalle factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void UpdateOrderDetail(int id, int productid, string amount)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("UpdateOrderDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@OrderId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);
                        command.Parameters.AddWithValue("@Amount", int.Parse(amount));
                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Pedido modificada correctamente.", "Detalle de Pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al modificar el detalle Pedido: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteOrderDetail(int id, int productid)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DeleteOrderDetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@OrderId", id);
                        command.Parameters.AddWithValue("@ProductId", productid);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                        MessageBox.Show("Detalle de Pedido borrado correctamente.", "Detalle de Pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al eliminar el detalle del pedido: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
