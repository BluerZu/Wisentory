﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Wisentory.Classes
{
    internal class DBFunctions
    {
        private string strconnection = ConfigurationManager.ConnectionStrings["WisentoryDB"].ConnectionString;
        //Clase que realiza la conexión con la base de datos.
        private SqlConnection GetConnection()
        {
            return new SqlConnection(strconnection);
        }

        public bool Conected()
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }

        //Clase que nos permite autentificar si el usuario es válido.
        public bool AuthenticateUser(string username, string password)
        {
            using (SqlConnection connection = GetConnection())
            {
                string query = "SELECT COUNT(*) FROM Users WHERE Name = @Name AND BINARY_CHECKSUM(Password) = BINARY_CHECKSUM(@Password)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    //Comandos para la sanitización de los datos.
                    command.Parameters.AddWithValue("@Name", username);
                    command.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        int count = (int)command.ExecuteScalar();
                        connection.Close();
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                        return false;
                    }

                }
            }
        }

        public DataTable FillClients(int pageNumber = 1, int pageSize = 5)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("GetPagedClients"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@PageNumber", pageNumber);
                        command.Parameters.AddWithValue("@PageSize", pageSize);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public DataTable FillTables(string procedure, int pageNumber = 1, int pageSize = 5)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(procedure))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@PageNumber", pageNumber);
                        command.Parameters.AddWithValue("@PageSize", pageSize);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }  

        public DataTable SearchClients(string name = "", string lastname = "", string number = "", string email = "")
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SearchClients"))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@name", name);
                        command.Parameters.AddWithValue("@lastname", lastname);
                        command.Parameters.AddWithValue("@number", number);
                        command.Parameters.AddWithValue("@email", email);
                        command.Connection = connection;
                        SqlDataAdapter adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;

                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public void InsertClient(string name, string lastName, string email = "", string phoneNumber = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strconnection))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertClient", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agregar los parámetros al procedimiento almacenado
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                        // Ejecutar el procedimiento almacenado
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                // Capturar la excepción y mostrar el mensaje de error
                MessageBox.Show("Error al insertar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
