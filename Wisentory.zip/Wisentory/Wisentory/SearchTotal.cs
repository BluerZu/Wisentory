﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wisentory.Classes;

namespace Wisentory
{
    public partial class SearchTotal : Form
    {
        public double total { get; private set; }
        public string condition { get; private set; }
        public SearchTotal()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SearchTotal_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Mayores");
            comboBox1.Items.Add("Menores");
            comboBox1.Items.Add("Iguales");
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                condition = "U";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                condition = "D";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                condition = "E";
            }
            ValidationFunctions valid = new ValidationFunctions();
            if (valid.IsPositiveDecimal(txt_total.Text)) {
                total = Math.Round(double.Parse(txt_total.Text), 2);
                this.DialogResult = DialogResult.OK;
            }
        }

    }
}
